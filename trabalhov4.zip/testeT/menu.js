const acaoButton = document.getElementById('acao');
const romanceButton = document.getElementById('romance');
const suspenseButton = document.getElementById('suspense');
const terrorButton = document.getElementById('terror');

acaoButton.addEventListener('click', function() {
  window.location.href = 'acao.html';
});

romanceButton.addEventListener('click', function() {
  window.location.href = 'romance.html';
});

suspenseButton.addEventListener('click', function() {
  window.location.href = 'suspense.html';
});

terrorButton.addEventListener('click', function() {
  window.location.href = 'terror.html';
});